function setup() {
  createCanvas(400, 400);
  background(220);       // gris claro
  line(50, 50, 350, 50); // línea horizontal
  ellipse(200, 200, 100, 100); // círculo en el centro
}